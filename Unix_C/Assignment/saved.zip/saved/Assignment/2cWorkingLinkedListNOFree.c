
#include "dictionary.h"
#include "Settings.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>



void dictionaryRead(char* dictionaryName)
{
	double linkedcount = 0;
	FILE *fp = NULL;
	char word[LONGEST_WORD_LENGTH];
	Dict *current, *head;
	
	head = current = NULL;
	fp = fopen(dictionaryName, "r");
	
	while(fgets(word, sizeof(word), fp))
	{
		Dict *node = malloc(sizeof(Dict));
		node->string = strdup(word);
		node->next =NULL;
		
		if(head == NULL)
		{
			current = head = node; /*everything is NULL*/
		}
		else
		{
			current = current->next = node;/*current node points to the next node*/
		}
	}
	
	fclose(fp);
	/*test print*/
	for(current = head; current ; current=current->next)
	{
		linkedcount++;
		printf("\t\tEntry %10.0lf:\t%s", linkedcount, current->string);
	}
	/*need to free linked list*/
	
}
