

#include <stdio.h>
#include "Settings.h"
#include <strings.h>
#include <stdlib.h>
#include "check.h"
/* ActionFunc Callback Function */

/* Function for when autocorrect is no */

int autocorrectNo(char* word, char* suggestion)
{
	int state = 0;
	char* wordUpdate;
	
	
	if(suggestion == NULL)
	{
		printf("No suggestion can be found, it is not possible to correct this");
		state = 0; /*FALSE*/
	}
	
	else
	{
		printf("Enter yes or no if you would like to correct:\n\t\t%s to\n\t\t%s\n", word, suggestion);
		
		scanf("%s", wordUpdate);
		
		if(strcmp(wordUpdate, "yes") == 0)
		{
			strcpy(word, suggestion);
			state = 1; /*TRUE*/
		}
		
		else if(strcmp(wordUpdate, "no") == 0)
		{
			state = 0; /*FALSE*/
		}
		
	}
	
	return state;
}


/* Function for when autocorrect is yes*/

int autocorrectYes(char* word, char* suggestion)
{
	int state =0;
	
	if(suggestion == NULL)
	{
		printf("No suggestion can be found, it is not possible to correct this");
		state = 0; /*FALSE*/
	}
	else
	{
		state = 1;
		strcpy(word, suggestion);
		printf("The corrected word is %50s", suggestion);
	}
	
	
	return state;
}



