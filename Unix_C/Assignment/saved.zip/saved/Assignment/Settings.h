
/*
 This header file was created to allow the settings struct to be used
 from any function no matter which ".c" the function was located.
 
 Note that the #ifndef statements are used to stop any duplicate entries
 */

#ifndef Settings_h
#define Settings_h

#include <stdio.h>

#ifndef DEBUG
#define DEBUG 0
#endif

typedef struct {
	int maxCorrection;
	char* dictionaryName;
	char* autocorrect;
} Settings;

void printSettings(Settings* set);

/*int autocorrectNo(char* word, char* suggestion);
int autocorrectYes(char* word, char* suggestion);

typedef int (*ActionFunc)(char* word, char* suggestion);

ActionFunc aNo = &autocorrectNo;
ActionFunc aYes = &autocorrectYes;
*/
#endif /* Settings_h */
