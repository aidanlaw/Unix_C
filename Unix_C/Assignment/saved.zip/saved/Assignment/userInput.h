
#ifndef userInput_h
#define userInput_h

#include <stdio.h>

/*sets a maximum allocation for characters stored within a single string of the linked list*/
#define LONGEST_WORD_LENGTH 64

/*declaration of the function called by the main.c*/
void inputRead(char* inputName, unsigned int* inputrow, unsigned int* completeInputLength,
					Directory* InputList, Dict* inputcurrent);

void inputArrayFunc(unsigned int completeInputLength);

void inputArrayCaller(unsigned int* inputrow, Directory* InputList, Dict* inputcurrent, char** inputArray, unsigned int *completeInputLength);

/*probably not required as only the dictionary.c calls these functions and they are before the main function anyway*/
unsigned int listToArrayDynamicInput(unsigned int inputrow, Directory* InputList, Dict* inputcurrent, char* inputArray[], unsigned int inputLength);


/*
 Function called upon by another function called "freeLinkedList".
 Frees each field within the current struct whilst saving the address of the next struct.
 This is the recursive part of the freeing code.
 */
void freeNodei(Dict* inputcurrent);
void freeLinkedListi(Directory* InputList);

#endif /* userInput_h */
